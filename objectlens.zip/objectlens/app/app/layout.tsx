import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ObjectLens · AI Detection",
  description: "Real-time object detection powered by YOLOv8",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
