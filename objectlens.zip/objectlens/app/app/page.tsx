"use client";

import { useRef, useState, useCallback } from "react";

// ── Types ─────────────────────────────────────────────────────────────────────
interface DetectedObject {
  label: string;
  count: number;
  max_conf: number;
}

interface DetectionResult {
  image: string;         // base64 PNG
  total: number;
  unique_classes: number;
  objects: DetectedObject[];
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function fileToBase64(file: File): Promise<string> {
  return new Promise((res, rej) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      res(result.split(",")[1]);
    };
    reader.onerror = rej;
    reader.readAsDataURL(file);
  });
}

// ── Sub-components ────────────────────────────────────────────────────────────

function StatCard({ value, label }: { value: string | number; label: string }) {
  return (
    <div className="flex-1 min-w-[90px] rounded-xl border border-[var(--border)] bg-[var(--surface)] p-4 text-center">
      <div className="font-display text-3xl font-bold" style={{ color: "var(--accent)" }}>
        {value}
      </div>
      <div className="font-mono text-[10px] tracking-widest uppercase mt-1" style={{ color: "var(--muted)" }}>
        {label}
      </div>
    </div>
  );
}

function ObjectRow({ obj }: { obj: DetectedObject }) {
  const pct = Math.round(obj.max_conf * 100);
  return (
    <div className="flex items-center justify-between rounded-lg border border-[var(--border)] bg-[var(--surface)] px-4 py-3">
      <span className="font-sans font-medium text-[var(--text)] capitalize">{obj.label}</span>
      <div className="flex items-center gap-3">
        {/* Confidence bar */}
        <div className="hidden sm:block w-24 h-1.5 rounded-full bg-[var(--border)] overflow-hidden">
          <div
            className="h-full rounded-full transition-all"
            style={{ width: `${pct}%`, background: "var(--accent)" }}
          />
        </div>
        <span className="font-mono text-xs" style={{ color: "var(--accent)" }}>{pct}%</span>
        <span
          className="font-mono text-[11px] rounded-full px-2 py-0.5"
          style={{ background: "var(--accent-dim)", color: "var(--accent)" }}
        >
          ×{obj.count}
        </span>
      </div>
    </div>
  );
}

// ── Page ──────────────────────────────────────────────────────────────────────
export default function Home() {
  const [tab, setTab] = useState<"upload" | "camera">("upload");
  const [conf, setConf] = useState(0.35);
  const [preview, setPreview] = useState<string | null>(null);
  const [fileB64, setFileB64] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<DetectionResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  // ── Image selection ──
  const handleFile = useCallback(async (file: File) => {
    setResult(null);
    setError(null);
    const url = URL.createObjectURL(file);
    setPreview(url);
    const b64 = await fileToBase64(file);
    setFileB64(b64);
  }, []);

  const onFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFile(file);
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file) handleFile(file);
  };

  // ── Detection ──
  const detect = async () => {
    if (!fileB64) return;
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const res = await fetch("/api/detect", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ image: fileB64, conf }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Detection failed");
      setResult(data);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  // ── Download ──
  const download = () => {
    if (!result) return;
    const a = document.createElement("a");
    a.href = `data:image/png;base64,${result.image}`;
    a.download = "detection_result.png";
    a.click();
  };

  return (
    <main className="min-h-dvh flex flex-col items-center px-4 py-10 max-w-2xl mx-auto">

      {/* ── Hero ── */}
      <header className="w-full text-center mb-10 animate-fade-up">
        <div
          className="font-mono text-[11px] tracking-[4px] uppercase mb-3"
          style={{ color: "var(--accent)" }}
        >
          YOLOv8 · Real-time Detection
        </div>
        <h1 className="font-display text-5xl sm:text-6xl font-extrabold tracking-tight leading-none">
          Object<span style={{ color: "var(--accent)" }}>Lens</span>
        </h1>
        <p className="mt-3 text-sm font-light" style={{ color: "var(--muted)" }}>
          Upload or snap a photo — get instant object detection with bounding boxes,
          labels, and confidence scores.
        </p>
      </header>

      {/* ── Settings bar ── */}
      <div
        className="w-full flex items-center gap-4 rounded-xl border border-[var(--border)] bg-[var(--surface)] px-5 py-3 mb-6 animate-fade-up"
        style={{ animationDelay: "0.05s" }}
      >
        <label className="font-mono text-[11px] tracking-widest uppercase whitespace-nowrap" style={{ color: "var(--muted)" }}>
          Confidence
        </label>
        <input
          type="range" min={0.1} max={0.95} step={0.05} value={conf}
          onChange={e => setConf(parseFloat(e.target.value))}
          className="flex-1 accent-[#b8ff57] cursor-pointer"
        />
        <span className="font-mono text-sm w-10 text-right" style={{ color: "var(--accent)" }}>
          {Math.round(conf * 100)}%
        </span>
      </div>

      {/* ── Tabs ── */}
      <div
        className="w-full flex rounded-xl border border-[var(--border)] bg-[var(--surface)] p-1 mb-4 animate-fade-up"
        style={{ animationDelay: "0.1s" }}
      >
        {(["upload", "camera"] as const).map(t => (
          <button
            key={t}
            onClick={() => { setTab(t); setPreview(null); setFileB64(null); setResult(null); }}
            className="flex-1 py-2 rounded-lg font-mono text-xs tracking-widest uppercase transition-all"
            style={{
              background: tab === t ? "var(--accent)" : "transparent",
              color: tab === t ? "#080808" : "var(--muted)",
            }}
          >
            {t === "upload" ? "📁 Upload" : "📷 Camera"}
          </button>
        ))}
      </div>

      {/* ── Input area ── */}
      <div className="w-full animate-fade-up" style={{ animationDelay: "0.15s" }}>
        {tab === "upload" ? (
          <div
            onDrop={onDrop}
            onDragOver={e => e.preventDefault()}
            onClick={() => fileInputRef.current?.click()}
            className="w-full rounded-xl border-2 border-dashed border-[var(--border)] flex flex-col items-center justify-center gap-2 py-10 cursor-pointer transition-colors hover:border-[var(--accent)] hover:bg-[var(--accent-dim)]"
          >
            <span className="text-3xl">🖼️</span>
            <p className="font-mono text-xs tracking-wide" style={{ color: "var(--muted)" }}>
              Drag & drop or click to select
            </p>
            <p className="font-mono text-[10px]" style={{ color: "var(--muted)" }}>
              JPG · PNG · WEBP · BMP
            </p>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={onFileChange}
            />
          </div>
        ) : (
          <div className="w-full rounded-xl border border-[var(--border)] bg-[var(--surface)] p-4 flex flex-col items-center gap-3">
            <input
              ref={cameraInputRef}
              type="file"
              accept="image/*"
              capture="environment"
              className="hidden"
              onChange={onFileChange}
            />
            <button
              onClick={() => cameraInputRef.current?.click()}
              className="rounded-full w-16 h-16 flex items-center justify-center text-2xl transition-transform active:scale-95"
              style={{ background: "var(--accent)", animation: "pulse-ring 2s infinite" }}
            >
              📷
            </button>
            <p className="font-mono text-[11px] tracking-wide" style={{ color: "var(--muted)" }}>
              Tap to open your camera
            </p>
          </div>
        )}
      </div>

      {/* ── Preview ── */}
      {preview && (
        <div className="w-full mt-4 rounded-xl overflow-hidden border border-[var(--border)] animate-fade-up">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={preview} alt="Preview" className="w-full object-contain max-h-80" />
        </div>
      )}

      {/* ── Detect button ── */}
      {fileB64 && (
        <button
          onClick={detect}
          disabled={loading}
          className="mt-5 w-full py-3 rounded-xl font-display font-bold text-sm tracking-widest uppercase transition-opacity disabled:opacity-50 animate-fade-up"
          style={{ background: "var(--accent)", color: "#080808" }}
        >
          {loading ? (
            <span className="flex items-center justify-center gap-2">
              <span className="inline-block w-4 h-4 border-2 border-[#080808] border-t-transparent rounded-full animate-spin" />
              Detecting…
            </span>
          ) : "Run Detection →"}
        </button>
      )}

      {/* ── Error ── */}
      {error && (
        <div className="mt-4 w-full rounded-xl border border-red-800 bg-red-950/40 px-4 py-3 font-mono text-xs text-red-400">
          {error}
        </div>
      )}

      {/* ── Results ── */}
      {result && (
        <section className="w-full mt-6 space-y-4 animate-fade-up">
          <div className="font-mono text-[11px] tracking-[4px] uppercase" style={{ color: "var(--accent)" }}>
            Results
          </div>

          {/* Annotated image */}
          <div className="rounded-xl overflow-hidden border border-[var(--border)]">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={`data:image/png;base64,${result.image}`}
              alt="Detection result"
              className="w-full object-contain"
            />
          </div>

          {/* Stats */}
          <div className="flex gap-3 flex-wrap">
            <StatCard value={result.total} label="Objects" />
            <StatCard value={result.unique_classes} label="Classes" />
            <StatCard
              value={
                result.objects.length
                  ? Math.round((result.objects.reduce((s, o) => s + o.max_conf * o.count, 0) / result.total) * 100) + "%"
                  : "—"
              }
              label="Avg Conf"
            />
          </div>

          {/* Object list */}
          {result.objects.length > 0 ? (
            <div className="space-y-2">
              {result.objects.map(obj => (
                <ObjectRow key={obj.label} obj={obj} />
              ))}
            </div>
          ) : (
            <p className="font-mono text-xs text-center py-4" style={{ color: "var(--muted)" }}>
              No objects detected above threshold.
            </p>
          )}

          {/* Download */}
          <button
            onClick={download}
            className="w-full py-2.5 rounded-xl border font-mono text-xs tracking-widest uppercase transition-colors hover:bg-[var(--accent-dim)]"
            style={{ borderColor: "var(--accent)", color: "var(--accent)" }}
          >
            ⬇ Download Result
          </button>
        </section>
      )}

      <footer className="mt-16 font-mono text-[10px] tracking-widest uppercase" style={{ color: "var(--muted)" }}>
        YOLOv8n · CPU · Ultralytics · Vercel
      </footer>
    </main>
  );
}
