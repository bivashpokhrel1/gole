# ObjectLens — AI Object Detection on Vercel

Real-time object detection with **YOLOv8n** — Next.js frontend + Python serverless API, deployed on Vercel.

## Project Structure

```
objectlens/
├── api/
│   └── detect.py          # Python serverless function (YOLOv8 inference)
├── app/                   # Next.js frontend
│   ├── app/
│   │   ├── layout.tsx
│   │   ├── page.tsx
│   │   └── globals.css
│   ├── package.json
│   ├── next.config.js
│   ├── tailwind.config.js
│   └── tsconfig.json
├── requirements.txt       # Python deps for Vercel
└── vercel.json            # Vercel config
```

## Deploy to Vercel

### 1. Push to GitHub

```bash
git init
git add .
git commit -m "initial commit"
gh repo create objectlens --public --push
```

### 2. Import on Vercel

1. Go to [vercel.com/new](https://vercel.com/new)
2. Import your GitHub repo
3. Set **Root Directory** to `app` (the Next.js folder)
4. Leave build settings as default (Vercel auto-detects Next.js)
5. Click **Deploy**

> Vercel automatically detects `api/detect.py` at the repo root and deploys it as a Python serverless function.

### 3. Environment

No environment variables required. YOLOv8n weights (`yolov8n.pt`) are auto-downloaded on first cold start and cached in `/tmp`.

---

## Local Development

### Python API (terminal 1)

```bash
pip install -r requirements.txt
# Vercel CLI dev server handles Python functions:
npx vercel dev
```

### Next.js frontend (terminal 2)

```bash
cd app
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

---

## Features

| Feature | Details |
|---|---|
| 📁 File upload | JPG, PNG, WEBP, BMP |
| 📷 Camera capture | Mobile-native via `capture="environment"` |
| 🎯 YOLOv8n detection | CPU-only, ~6 MB model |
| 📊 Stats | Object count, classes, avg confidence |
| 📥 Download | Annotated image as PNG |
| ⚙️ Confidence slider | Adjustable threshold (10–95%) |

## Tech Stack

- **Frontend**: Next.js 14, TypeScript, Tailwind CSS
- **Backend**: Python 3.11 serverless (Vercel), YOLOv8n, OpenCV, Pillow
- **Deployment**: Vercel

## Notes

- Cold starts may take ~10–15 s on first request (model download + import)
- Vercel serverless functions have a 60 s timeout (configured in `vercel.json`)
- Memory is set to 1024 MB to handle YOLOv8 inference
